<?php

require __DIR__ . '/../vendor/autoload.php';
$director = new App\Architect;
$builder1 = new App\Architect;
$builder2 = new App\Architect;
$director->createMyOldHouse($builder1);
$director->createMyOldHouse($builder2);
print '-- Novice Carpenter --' . PHP_EOL;
print $builder1->getHouse();
print PHP_EOL . '-- Expert Carpenter --' . PHP_EOL;
print $builder2->getHouse();
