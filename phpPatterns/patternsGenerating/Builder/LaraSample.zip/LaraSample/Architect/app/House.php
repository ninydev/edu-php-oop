<?php


class House {
  public $layout;
}
